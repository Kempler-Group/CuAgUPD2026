EC-LAB SETTING FILE

Number of linked techniques : 1

EC-LAB for windows v11.60 (software)
Internet server v11.60 (firmware)
Command interpretor v11.60 (firmware)

Filename : C:\Users\boettcherlab\Documents\EC-Lab\Data\Stern\jan 2025\30-1-25 10 mM Cu fresh\PEIS_after_Au(st007)_Pt_Cu[10mM]_100-10_mM_PCA-Cu_300125.mps

Device : SP-300
Electrode connection : standard
Potential control : Ewe
Ewe ctrl range : min = -2.50 V, max = 2.50 V
Ewe,I filtering : 50 kHz
Safety Limits :
	Do not start on E overload
Channel : Floating
Electrode material : 
Initial state : 
Electrolyte : 
Comments : 
Mass of active material : 0.001 mg
 at x = 0.000
Molecular weight of active material (at x = 0) : 0.001 g/mol
Atomic weight of intercalated ion : 0.001 g/mol
Acquisition started at : xo = 0.000
Number of e- transfered per intercalated ion : 1
for DX = 1, DQ = 26.802 mA.h
Battery capacity : 0.000 A.h
Cable : standard
Electrode surface area : 0.000 cm�
Characteristic mass : 0.001 g
Volume (V) : 0.001 cm�
Cycle Definition : Charge/Discharge alternance
Do not turn to OCV between techniques

Technique : 1
Potentio Electrochemical Impedance Spectroscopy
Mode                Single sine         
E (V)               0.6000              
vs.                 Ref                 
tE (h:m:s)          0:00:0.0000         
record              0                   
dI                  0.000               
unit dI             mA                  
dt (s)              0.000               
fi                  200.000             
unit fi             kHz                 
ff                  200.000             
unit ff             mHz                 
Nd                  6                   
Points              per decade          
spacing             Logarithmic         
Va (mV)             10.0                
pw                  0.10                
Na                  2                   
corr                0                   
E range min (V)     -2.500              
E range max (V)     2.500               
I Range             Auto                
Bandwidth           8                   
nc cycles           0                   
goto Ns'            0                   
nr cycles           0                   
inc. cycle          0                   
