EC-LAB SETTING FILE

Number of linked techniques : 2

EC-LAB for windows v11.60 (software)
Internet server v11.60 (firmware)
Command interpretor v11.60 (firmware)

Filename : C:\Users\boettcherlab\Documents\EC-Lab\Data\Stern\aug 2025\2025-08-21 1 mM Cu - 100 mM HSA\CV-1000_Au(st060)_Pt_Cu[1mM]_100-1_HSA-Cu_20250821.mps

Device : SP-300
Electrode connection : standard
Potential control : Ewe
Ewe ctrl range : min = -2.50 V, max = 2.50 V
Ewe,I filtering : 50 kHz
Safety Limits :
	Do not start on E overload
Channel : Grounded
Electrode material : 
Initial state : 
Electrolyte : 
Comments : 
Cable : standard
Electrode surface area : 0.001 cm�
Characteristic mass : 0.001 g
Equivalent Weight : 0.000 g/eq.
Density : 0.000 g/cm3
Volume (V) : 0.001 cm�
Cycle Definition : Charge/Discharge alternance
Turn to OCV between techniques

Technique : 1
Manual IR compensation
Ru                  36.384              
unit Ru             Ohm                 
comp. level (%)     85                  
comp. mode          Software            

Technique : 2
Cyclic Voltammetry
Ei (V)              0.600               
vs.                 Ref                 
dE/dt               1000.000            
dE/dt unit          mV/s                
E1 (V)              0.000               
vs.                 Ref                 
Step percent        1                   
N                   1                   
E range min (V)     -2.500              
E range max (V)     2.500               
I Range             1 mA                
I Range min         Unset               
I Range max         Unset               
I Range init        Unset               
Bandwidth           8                   
E2 (V)              0.600               
vs.                 Ref                 
nc cycles           2                   
Reverse Scan        1                   
Ef (V)              0.000               
vs.                 Ei                  
