EC-Lab LOG FILE

Chronoamperometry / Chronocoulometry

Run on channel : 1 (SN 2761)
User : 
Electrode connection : standard
Potential control : Ewe
Ewe ctrl range : min = -2.50 V, max = 2.50 V
Ewe,I filtering : <None>
Safety Limits :
	Do not start on E overload
Channel : Floating
Acquisition started on : 08/21/2025 16:01:19.060
Loaded Setting File : NONE
Saved on :
	File : LSV_10-test2_Au(st060)_Pt_Cu[1mM]_100-1_HSA-Cu_20250821_02_CA_C01.mpr
	Directory : C:\Users\boettcherlab\Documents\EC-Lab\Data\Stern\aug 2025\2025-08-21 1 mM Cu - 100 mM HSA\strip 0p25 V\
	Host : 192.168.0.243
Device : SP-300 (SN 0519)
Address : USB
EC-LAB for windows v11.60 (software)
Internet server v11.60 (firmware)
Command interpretor v11.60 (firmware)
Electrode material : 
Initial state : 
Electrolyte : 
Comments : 
Mass of active material : 0.001 mg
 at x = 0.000
Molecular weight of active material (at x = 0) : 0.001 g/mol
Atomic weight of intercalated ion : 0.001 g/mol
Acquisition started at : xo = 0.000
Number of e- transfered per intercalated ion : 1
for DX = 1, DQ = 26.802 mA.h
Battery capacity : 0.000 A.h
Cable : standard
Electrode surface area : 0.000 cm�
Characteristic mass : 0.001 g
Volume (V) : 0.001 cm�
Cycle Definition : Charge/Discharge alternance
Ei (V)              0.250               
vs.                 Ref                 
ti (h:m:s)          0:00:10.0000        
Imax                pass                
unit Imax           mA                  
Imin                pass                
unit Imin           mA                  
dQM                 0.000               
unit dQM            mA.h                
record              <I>                 
dI                  5.000               
unit dI             �A                  
dQ                  0.000               
unit dQ             mA.h                
dt (s)              0.1000              
dta (s)             0.1000              
E range min (V)     -2.500              
E range max (V)     2.500               
I Range             Auto                
I Range min         Unset               
I Range max         Unset               
I Range init        Unset               
Bandwidth           8                   
goto Ns'            0                   
nc cycles           0                   

Modify on : 08/21/2025 16:01
Ei (V)              0.230               
