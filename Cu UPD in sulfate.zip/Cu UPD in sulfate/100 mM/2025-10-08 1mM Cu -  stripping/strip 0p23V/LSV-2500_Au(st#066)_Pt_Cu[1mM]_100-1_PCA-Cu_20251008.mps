EC-LAB SETTING FILE

Number of linked techniques : 3

EC-LAB for windows v11.60 (software)
Internet server v11.60 (firmware)
Command interpretor v11.60 (firmware)

Filename : C:\Users\boettcherlab\Documents\EC-Lab\Data\Stern\nov 2025\2025-10-08 1mM Cu - 100 HSA stripping\strip 0p23V\LSV-2500_Au(st#066)_Pt_Cu[1mM]_100-1_PCA-Cu_20251008.mps

Device : SP-300
Electrode connection : standard
Potential control : Ewe
Ewe ctrl range : min = -2.50 V, max = 2.50 V
Ewe,I filtering : <None>
Safety Limits :
	Do not start on E overload
Channel : Floating
Electrode material : 
Initial state : 
Electrolyte : 
Comments : 
Mass of active material : 0.001 mg
 at x = 0.000
Molecular weight of active material (at x = 0) : 0.001 g/mol
Atomic weight of intercalated ion : 0.001 g/mol
Acquisition started at : xo = 0.000
Number of e- transfered per intercalated ion : 1
for DX = 1, DQ = 26.802 mA.h
Battery capacity : 0.000 A.h
Cable : standard
Electrode surface area : 0.000 cm�
Characteristic mass : 0.001 g
Volume (V) : 0.001 cm�
Cycle Definition : Charge/Discharge alternance
Turn to OCV between techniques

Technique : 1
Manual IR compensation
Ru                  34.957              
unit Ru             Ohm                 
comp. level (%)     85                  
comp. mode          Software            

Technique : 2
Chronoamperometry / Chronocoulometry
Ei (V)              0.230               
vs.                 Ref                 
ti (h:m:s)          0:00:10.0000        
Imax                pass                
unit Imax           mA                  
Imin                pass                
unit Imin           mA                  
dQM                 0.000               
unit dQM            mA.h                
record              <I>                 
dI                  5.000               
unit dI             �A                  
dQ                  0.000               
unit dQ             mA.h                
dt (s)              0.1000              
dta (s)             0.1000              
E range min (V)     -2.500              
E range max (V)     2.500               
I Range             Auto                
I Range min         Unset               
I Range max         Unset               
I Range init        Unset               
Bandwidth           8                   
goto Ns'            0                   
nc cycles           0                   

Technique : 3
Linear Sweep Voltammetry
tR (h:m:s)          0:00:0.0000         
dER/dt (mV/h)       0.0                 
dER (mV)            0                   
dtR (s)             0.0000              
dE/dt               2500.000            
dE/dt unit          mV/s                
Ei (V)              0.230               
vs.                 Ref                 
EL (V)              0.700               
vs.                 Ref                 
record              <I>                 
dI                  0.000               
unit dI             �A                  
tI (s)              0.0000              
step percent        1                   
N                   1                   
E range min (V)     -2.500              
E range max (V)     2.500               
I Range             1 mA                
I Range min         Unset               
I Range max         Unset               
I Range init        Unset               
Bandwidth           8                   
