EC-LAB SETTING FILE

Number of linked techniques : 2

EC-LAB for windows v11.50 (software)
Internet server v11.50 (firmware)
Command interpretor v11.50 (firmware)

Filename : C:\Users\boettcherlab\Documents\EC-Lab\Data\Boettcher Lab\Stern\oct 2024\16-10-24 PCA blank\CV-30_#012_Au(kt005)_Pt_MSE_100mM_161024.mps

Device : SP-300
Electrode connection : standard
Potential control : Ewe
Ewe ctrl range : min = -2.50 V, max = 2.50 V
Ewe,I filtering : 50 kHz
Safety Limits :
	Do not start on E overload
Channel : Floating
Electrode material : 
Initial state : 
Electrolyte : 
Comments : 
Mass of active material : 0.001 mg
 at x = 0.000
Molecular weight of active material (at x = 0) : 0.001 g/mol
Atomic weight of intercalated ion : 0.001 g/mol
Acquisition started at : xo = 0.000
Number of e- transfered per intercalated ion : 1
for DX = 1, DQ = 26.802 mA.h
Battery capacity : 0.000 A.h
Cable : standard
Electrode surface area : 0.000 cm�
Characteristic mass : 0.001 g
Volume (V) : 0.001 cm�
Cycle Definition : Charge/Discharge alternance
Do not turn to OCV between techniques

Technique : 1
Potentio Electrochemical Impedance Spectroscopy
Mode                Single sine         
E (V)               0.0000              
vs.                 Ref                 
tE (h:m:s)          0:00:0.0000         
record              0                   
dI                  0.000               
unit dI             mA                  
dt (s)              0.000               
fi                  200.000             
unit fi             kHz                 
ff                  200.000             
unit ff             mHz                 
Nd                  6                   
Points              per decade          
spacing             Logarithmic         
Va (mV)             10.0                
pw                  0.10                
Na                  2                   
corr                0                   
E range min (V)     -2.500              
E range max (V)     2.500               
I Range             Auto                
Bandwidth           8                   
nc cycles           0                   
goto Ns'            0                   
nr cycles           0                   
inc. cycle          0                   

Technique : 2
Cyclic Voltammetry
Ei (V)              0.470               
vs.                 Ref                 
dE/dt               30.000              
dE/dt unit          mV/s                
E1 (V)              -0.230              
vs.                 Ref                 
Step percent        50                  
N                   10                  
E range min (V)     -2.500              
E range max (V)     2.500               
I Range             10 �A               
I Range min         Unset               
I Range max         Unset               
I Range init        Unset               
Bandwidth           8                   
E2 (V)              0.470               
vs.                 Ref                 
nc cycles           200                 
Reverse Scan        1                   
Ef (V)              0.110               
vs.                 Ref                 
