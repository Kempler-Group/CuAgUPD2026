EC-LAB SETTING FILE

Number of linked techniques : 1

EC-LAB for windows v11.60 (software)
Internet server v11.60 (firmware)
Command interpretor v11.60 (firmware)

Filename : C:\Users\boettcherlab\Documents\EC-Lab\Data\Stern\apr 2025\2025-04-24 100 mM PCA\OCV_Au(st#038)_Pt_MSE_100_PCA-BLANK_20250424_02_CV.mps

Device : SP-300
Electrode connection : standard
Potential control : Ewe
Ewe ctrl range : min = -10.00 V, max = 10.00 V
Ewe,I filtering : 50 kHz
Safety Limits :
	Do not start on E overload
Channel : Grounded
Electrode material : 
Initial state : 
Electrolyte : 
Comments : 
Cable : standard
Electrode surface area : 0.001 cm�
Characteristic mass : 0.001 g
Equivalent Weight : 0.000 g/eq.
Density : 0.000 g/cm3
Volume (V) : 0.001 cm�
Cycle Definition : Charge/Discharge alternance
Turn to OCV between techniques

Technique : 1
Open Circuit Voltage
tR (h:m:s)          3:45:30.0000        
dER/dt (mV/h)       0.0                 
record              <Ewe>               
dER (mV)            0.00                
dtR (s)             0.5000              
E range min (V)     -10.000             
E range max (V)     10.000              
